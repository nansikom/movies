My file runs with ./file as an executable. and gnu99 for running.
gcc --std=gnu99 -g -o  file readin.c
The executable is called ./file.